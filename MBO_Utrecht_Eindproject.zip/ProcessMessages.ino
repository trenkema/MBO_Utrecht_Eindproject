void processMessages(const uint8_t * mac, const uint8_t *data, int len) {
  memcpy(&incomingData, data, sizeof(incomingData));
  
  if (strcmp(incomingData.message, "Ready_Confirmed") == 0){
    readyUpActive = false;

    delay(250);

    clearReadyPulse();

    startGame(selectedMode);
  }
  if (symbolPuzzleUnlocked) symbolMessages(incomingData.message);
  if (mazePuzzleUnlocked) mazeMessages(incomingData.message);
}

void symbolMessages(const char* message) {
  if (strcmp(message, "Symbol_Puzzle_Solved") == 0) {
    symbolPuzzleSolved();
  }
}

void mazeMessages(const char* message) {
}